static void run()
{
    Duck donald = new Duck("Donald");
    Duck picsou = new Duck("Picsou");
    donald.Fly();
    picsou.Fly();
}

run();

class Duck(string name)
{
    public string Name { get; set; } = name;

    public void Fly()
    {
        Console.WriteLine("I'm " + Name + " and I'm flying by myself!");
    }
}