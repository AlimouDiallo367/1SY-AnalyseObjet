static void run()
{
    //Démonstration de l'abstraction avec une classe abstraite Duck
    Mallard mallard = new Mallard("Donald");
    Redhead Redhead = new Redhead("Picsou");
    mallard.Fly();
    Redhead.Fly();
}

run();
abstract class Duck(string name) //On utilise ici les "primary constructors" de C# 9
{
    public string Name { get; set; } = name;

    public abstract void Fly();
}

class Mallard(string name) : Duck(name)
{
    public override void Fly()
    {
        Console.WriteLine(Name + " is flying !");
    }
}

class Redhead(string name) : Duck(name)
{
    public override void Fly()
    {
        Console.WriteLine("I'm " + Name + " and I'm very high in the sky !");
    }
}