static void run()
{
    Mallard mallard = new Mallard("Donald");
    Redhead Redhead = new Redhead("Picsou");
    RubberDuck rubberDuck = new RubberDuck("Duckie");

    /*
        L'analyseur statique empêche maintenant ce code
        mallard.Squeak();
        Redhead.Squeak();
        rubberDuck.Fly();
    */
    mallard.Fly();
    Redhead.Fly();
    rubberDuck.Squeak();
}

run();

interface IFlyable
{
    void Fly();
}

interface ISqueakable
{
    void Squeak();
}

abstract class Duck(string name)
{
    public string Name { get; set; } = name;
}

class Mallard(string name) : Duck(name), IFlyable
{
    public void Fly()
    {
        Console.WriteLine(Name + " is flying !");
    }
}

class Redhead(string name) : Duck(name), IFlyable
{
    public void Fly()
    {
        Console.WriteLine("I'm " + Name + " and I'm very high in the sky !");
    }
}

class RubberDuck(string name) : Duck(name), ISqueakable
{
    public void Squeak()
    {
        Console.WriteLine("Squeak! Squeak! from " + Name);
    }
}