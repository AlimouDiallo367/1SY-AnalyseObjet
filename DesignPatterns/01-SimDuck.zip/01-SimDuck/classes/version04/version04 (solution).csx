static void run()
{
    Duck thisDuck;
    Mallard mallard = new Mallard("Donald");
    Redhead Redhead = new Redhead("Picsou");
    RubberDuck rubberDuck = new RubberDuck("Duckie");
    DecoyDuck decoyDuck = new DecoyDuck("Woody");

    thisDuck = mallard;
    ((Mallard)thisDuck).Quack();
    thisDuck = decoyDuck;
    ((DecoyDuck)thisDuck).Display();

    mallard.Display();
    Redhead.Fly();
    rubberDuck.Squeak();
    decoyDuck.Display();
}

run();

interface IFlyable
{
    void Fly();
}

interface ISqueakable
{
    void Squeak();
}

interface IQuackable
{
    void Quack();
}

abstract class Duck(string name)
{
    public string Name { get; set; } = name;
    public abstract void Display();
}

class Mallard(string name) : Duck(name), IFlyable, IQuackable
{
    public void Fly()
    {
        Console.WriteLine(Name + " is flying !");
    }
    public void Quack()
    {
        Console.WriteLine(Name + " is telling you Quack! Quack! Quack!");
    }
    public override void Display()
    {
        Console.WriteLine("I'm a Mallard duck named " + Name);
    }
}

class Redhead(string name) : Duck(name), IFlyable, IQuackable
{
    public void Fly()
    {
        Console.WriteLine("I'm " + Name + " and I'm very high in the sky !");
    }
    public void Quack()
    {
        Console.WriteLine("I'm" + Name + " and I quack very loud!");
    }
    public override void Display()
    {
        Console.WriteLine("I'm a Redhead duck named " + Name);
    }
}

class RubberDuck(string name) : Duck(name), ISqueakable
{
    public void Squeak()
    {
        Console.WriteLine("Squeak! Squeak! from " + Name);
    }
    public override void Display()
    {
        Console.WriteLine("I'm a Rubber duck named " + Name);
    }
}

class DecoyDuck(string name) : Duck(name)
{
    public override void Display()
    {
        Console.WriteLine("I'm a Decoy duck named " + Name);
    }
}