static void run()
{
    Mallard mallard = new Mallard("Donald");
    Redhead Redhead = new Redhead("Picsou");
    RubberDuck rubberDuck = new RubberDuck("Duckie");

    mallard.Fly();
    Redhead.Fly();
    rubberDuck.Squeak();

    //Il y a problème ici car c'est possible de faire :
    mallard.Squeak();
    Redhead.Squeak();
    rubberDuck.Fly();
}
run();

abstract class Duck(string name)
{
    public string Name { get; set; } = name;

    public abstract void Fly();
    public abstract void Squeak();
}

class Mallard(string name) : Duck(name)
{
    public override void Fly()
    {
        Console.WriteLine(Name + " is flying !");
    }
    public override void Squeak()
    {
        Console.WriteLine("Don't do that to me !");
    }
}

class Redhead(string name) : Duck(name)
{
    public override void Fly()
    {
        Console.WriteLine("I'm " + Name + " and I'm very high in the sky !");
    }
        public override void Squeak()
    {
        Console.WriteLine("Don't do that to me !");
    }
}

class RubberDuck(string name) : Duck(name)
{
    public override void Squeak()
    {
        Console.WriteLine("Squaek! Squeak! from " + Name);
    }
    public override void Fly()
    {
        Console.WriteLine("Doh! I'm a rubber duck and I'm not supposed to fly!");
    }
}