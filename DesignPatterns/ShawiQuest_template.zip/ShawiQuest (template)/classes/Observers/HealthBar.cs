class HealthBar {

}
